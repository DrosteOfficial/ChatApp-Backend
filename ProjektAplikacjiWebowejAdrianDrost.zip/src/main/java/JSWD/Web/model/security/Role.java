package JSWD.Web.model.security;

public enum Role {
    ROLE_USER,
    ROLE_MODERATOR,
    ROLE_ADMIN
}
